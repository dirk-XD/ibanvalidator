package de.example.ibanvalidator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbanvalidatorApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("Context loaded! :)");
	}
}
